package com.hivenet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class HivenetApplication {

	public static void main(String[] args) {
		SpringApplication.run(HivenetApplication.class, args);
	}

}
